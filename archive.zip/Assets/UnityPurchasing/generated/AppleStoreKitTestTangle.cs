// WARNING: Do not modify! Generated file.

namespace UnityEngine.Purchasing.Security {
    public class AppleStoreKitTestTangle
    {
        private static byte[] data = System.Convert.FromBase64String("tgHVJMNHJilSJVD1pLuuU26mW81llnDxARy3+Iv0C55+Yxdfa45LyLk+UTKSI7hScC9V3NNwegJLSKWRqg9pi4kQlbQb4AiAGfP9MUG9xPINSGhJdn96LH1zdXEqDRYLHDIQDTLqwnOB2FhHsRigXbEnZgxHo+qiSGPo+cDGnHWyRcJ3PRtfg31QzzDy1YzmyXBB2hcCsl8pc2OY8KgLD7YdRRT5IEr1s09/U2hi9DC3cYYfONwHcPTDRES0CS6hlJasow6x6n1ySXB/eix9f2p7LCpIbklsf3BT/x5cwNIVShzUobvjATF2kLW4XnS/Sft6DUn7eyXZent4e3t4eEl0f3Br+q/+ARTgxCfKc5nht4+TuvcUEJLOOfhE/kQJKKi9JPTcpQYTIWOnGQ9OK5WG1WAkdWxW83aM8LGuUmRyQDWyNhe5yibO7MPA0SQzDdKWFnVxKg0WCxwyEA1Icklwf3osfX9qdMJB6RJ/vYV0nOwptOixw1yNIbBzdXEqDRYLHDIQDUhoSXZ/eix9cp4WmWKfdBG0XBe6D3GMM3LXAw1FMf+OdHhweG9xKg0WCxwyEA1J+3iOdHh4cnx5evt4eHnLeZlFiJGQG316dXEqDRYLHDIQDUhoSXZ/eix9SGhJdn96LH1ydXEqDRYLHDIQDUjggsrzLOaWZFHBJlOoCuZMPk7CP/wBMbe5vGtoE3Z111Z8sxYDHQZZeIZ9fXp7e/1Jb396LGRceHiGfXVVDJ81yGuqhJpmJ3QEwSGu2QWdBklzf3FSf3h8fH56ekl0f3BT/zH/U/8x/450eHhyfHlJJkhoSXZ/eiwqDRYLHDIQDUlnbnRLSUlNSUhITnlJ+3hze/t4eHmiBulFVQp2ou5fSSZIaEl2f3osfXp1cSoNFgscMhB7LCpIbklsf3BT/zH/jnR4cHhvccS5r2Q55y7AQekODyur0TIJF8EeZGp4eIZ9fEl6eHiGSXd/eixkdnhbSXR/cFP/Mf+OdHh4eHx5evt4dhrS7uNSulOhqcuYrCN0QGIWHlHQvdByyrYbdoLNxY6i/SdRkj50iJSunQHR1tEU3rijEVQftbZQcilVmruCnyZruHt6eHl42kJJQEl2f3os9ZgIojM8ilRg73ov+N89lwwOIipMS0pMI250TUlJSktOSE5MS0pMI2eVUuh83kQ2");
        private static int[] order = new int[] { 25,22,37,34,9,15,16,19,36,21,11,35,25,41,42,43,20,21,23,34,21,25,31,37,35,33,38,29,39,30,31,33,42,36,43,42,39,41,40,41,40,41,42,43,44 };
        private static int key = 121;

        public static readonly bool IsPopulated = true;

        public static byte[] Data() {
        	if (IsPopulated == false)
        		return null;
            return Obfuscator.DeObfuscate(data, order, key);
        }
    }
}
