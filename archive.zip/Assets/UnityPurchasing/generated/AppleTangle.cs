// WARNING: Do not modify! Generated file.

namespace UnityEngine.Purchasing.Security {
    public class AppleTangle
    {
        private static byte[] data = System.Convert.FromBase64String("8dfz4eSy4+T06qaXl4uCx7WIiJOTj4iVjpOe1vHX8+HksuPk9Oqml53XZeaR1+nh5LL66ObmGOPj5OXmkJDJhpeXi4LJhIiKyIaXl4uChIbXZeNc12XkREfk5ebl5ebl1+rh7ouCx66JhMnWwdfD4eSy4+z0+qaX+HY8+aC3DOIKuZ5jygzRRbCrsgvvuddl5vbh5LL6x+Nl5u/XZebj14mDx4SIiYOOk46IiZTHiIHHkpSCPtGYJmCyPkB+XtWlHD8ylnmZRrVolGaHIfy87sh1VR+jrxeH33nyEtTRvdeF1uzX7uHksuPh9OWytNb0wwUMNlCXOOiiBsAtFoqfCgBS8PD4YmRi/H7aoNAVTnynacszVnf1P0xElnWgtLImSMimVB8cBJcqAUSrmKZPfx42LYF7w4z2N0RcA/zNJPhn88w3jqBzke4ZE4xqyadBEKCqmIBo71PHECxLy8eIl1HY5tdrUKQox4iBx5OPgseTj4KJx4aXl4uOhIbh5LL66ePx4/PMN46gc5HuGROMar5A4u6b8Kex9vmTNFBsxNygRDKInseGlJSSioKUx4aEhIKXk4aJhIKXi4LHpIKVk46BjoSGk46IicemksmnQRCgqpjvudf44eSy+sTj/9fx0X6ryp9QCmt8OxSQfBWRNZDXqCa1gouOhomEgseIiceTj46Ux4SCldLV1tPX1NG98OrU0tfV197V1tPXzWGvYRDq5ubi4ufXhdbs1+7h5LKTjoGOhIaTgseFnseGiZ7Hl4aVk6KZ+KuMt3GmbiOThez3ZKZg1G1mhYuCx5SThomDhpWDx5OClYqUx4ZPO5nF0i3CMj7oMYwzRcPE9hBGS1LdShPo6ed17FbG8cmTMtvqPIXx2sGAx23UjRDqZSg5DETIHrSNvIOD0sTyrPK++lRzEBF7eSi3XSa/ty7+lRK66TKYuHwVwuRdsmiquuoW6HraFMyuz/0vGSlSXuk+ufsxLNrX9uHksuPt9O2ml5eLgseuiYTJ1mXm5+HuzWGvYRCEg+Lm12YV183hUPxadKXD9c0g6PpRqnu5hC+sZ/ByeZ3rQ6BsvDPx0NQsI+iqKfOONpeLgse1iIiTx6Sm1/nw6tfR19PVVte/C73j1WuPVGj6OYKUGIC5gluVhoSTjoSCx5SThpOCioKJk5TJ1+HX6OHksvr05uYY4+LX5ObmGNf6bP5uOR6sixLgTMXX5Q//2R+37jTB18Ph5LLj7PT6ppeXi4LHpIKVk8eGiYPHhIKVk46BjoSGk46IiceX6uHuzWGvYRDq5ubi4ufkZebm57vj4fTlsrTW9Nf24eSy4+307aaXl8jXZiTh78zh5uLi4OXl12ZR/WZUrj+ReNTzgkaQcy7K5eTm5+ZEZeYnhNSQEN3gy7EMPejG6T1dlP6oUuALmt5kbLTHNN8jVlh9qO2MGMwb4ufkZebo59dl5u3lZebm5wN2Tu5ZE5R8CTWD6CyeqNM/RdkenxiML+/M4ebi4uDl5vH5j5OTl5TdyMiQy8eEgpWTjoGOhIaTgseXiIuOhJ7HpKbXZebF1+rh7s1hr2EQ6ubm5o6BjoSGk46IicemkpOPiJWOk57Wt01tMj0DGzfu4NBXkpLG");
        private static int[] order = new int[] { 12,5,28,36,12,36,15,33,43,58,55,43,53,49,24,17,32,21,41,30,52,40,53,31,48,38,33,36,39,38,42,54,54,56,52,42,53,58,52,59,41,41,56,46,52,54,55,54,54,59,58,53,57,53,54,58,56,57,59,59,60 };
        private static int key = 231;

        public static readonly bool IsPopulated = true;

        public static byte[] Data() {
        	if (IsPopulated == false)
        		return null;
            return Obfuscator.DeObfuscate(data, order, key);
        }
    }
}
