= Native Share for Android & iOS (v1.5.2) =

Documentation: https://github.com/yasirkula/UnityNativeShare
FAQ: https://github.com/yasirkula/UnityNativeShare#faq
Example code: https://github.com/yasirkula/UnityNativeShare#example-code
E-mail: yasirkula@gmail.com